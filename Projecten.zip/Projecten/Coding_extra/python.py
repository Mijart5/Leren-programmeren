x = 3.40
y = 2.45
z = 1.95
btw = 1.09

print ((x + y + z) * btw)