pi = 3.14
straal = 2


print(straal * straal * pi)