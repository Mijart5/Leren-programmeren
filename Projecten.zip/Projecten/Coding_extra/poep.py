inputlengte = input('geef lengte op')                   #Input
inputbreedte = input('geef breedte op')

lengte = float(inputlengte)                             #Calculating
breedte =  float(inputbreedte)

oppervlakte = lengte * breedte                          #Output
print('lengte' , lengte)
print('breedte' , breedte)
print('oppervlakte' , oppervlakte)