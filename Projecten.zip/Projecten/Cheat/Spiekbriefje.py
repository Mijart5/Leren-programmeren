# zo maak je commentaar

#||||||||||||||||||||||||||||||||||||
# dit zijn variablen
#||||||||||||||||||||||||||||||||||||

aantal = 3   # dit is een integer
omschrijving = "Lays naturel 300gr" #dit is een string
prijs = 0.89 #dit is een float

#||||||||||||||||||||||||||||||||||||||
# beeld in functies
#||||||||||||||||||||||||||||||||||||||

print(f'{aantal} {omschrijving} {prijs} totaal prijs = {aantal*prijs:.2f}')