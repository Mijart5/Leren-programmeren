count = int(input("aantal: "))
item = input("item: ")
price = float(input("prijs: "))
print(f'{count} {item}  {price} {count*price:.2f}')