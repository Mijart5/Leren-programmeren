aantal = 3
omschrijving = "Lays naturel 300gr"
prijs = 0.89

Lays = f'{aantal} {omschrijving} {prijs} {aantal*prijs:.2f}'

print(Lays)

aantal = 5
omschrijving = "pinda"
prijs = 0.50

Pinda = f'{aantal} {omschrijving} {prijs} {aantal*prijs:.2f}'

print(Pinda)